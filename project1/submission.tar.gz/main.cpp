#include <iostream>
#include <chrono>
#include <fstream>

#include "Joiner.hpp"
#include "Parser.hpp"
#include "Threadpool.hpp"
#include "Executeoptions.hpp"


using namespace std;


#ifdef MULTI_THREAD_MODE
ThreadPool threadpool(48);
#endif
std::atomic<int> timecount = 0;

int main(int argc, char* argv[]) 
{
   Joiner joiner;
   
   
   // Read join relations
   
   string line;
   
   while (getline(cin, line)) 
   {
      if (line == "Done") break;
      
      joiner.addRelation(line.c_str());
   }


   // Preparation phase (not timed)
   // Build histograms
#ifdef QUERY_OPTIMIZE_MODE
#ifdef SINGLE_THREAD_MODE
   for (size_t i = 0; i < joiner.relations.size(); i++)
   {
      joiner.relations[i].BuildHistogram(); 
   }
#endif
#ifdef MULTI_THREAD_MODE
   std::vector<std::future<void>> bulid_histograms;

   for (size_t i = 0; i < joiner.relations.size(); i++)
   {
      bulid_histograms.push_back(std::move(threadpool.Request([&joiner, i]() mutable { joiner.relations[i].BuildHistogram(); })));
   }

   for (int i = 0; i < bulid_histograms.size(); i++)
   {
      bulid_histograms[i].wait();
   }
#endif
#endif


#ifdef SINGLE_THREAD_MODE
   QueryInfo i;
#endif
#ifdef MULTI_THREAD_MODE
   std::vector<std::future<string>> results;
#endif

   
   while (getline(cin, line)) 
   {
      if (line == "F")
      {
#ifdef MULTI_THREAD_MODE
        for (int i = 0; i < results.size(); i++)
        {
            std::cout << results[i].get();
        }

        results.clear();
#endif
        continue;
      }

#ifdef SINGLE_THREAD_MODE
      i.parseQuery(line);

      cout << joiner.join(i);
#endif
#ifdef MULTI_THREAD_MODE
      results.push_back(std::move(threadpool.Request([&joiner, line]() mutable { QueryInfo i; i.parseQuery(line); return joiner.join(i); })));
#endif
   }

   std::cerr << timecount << std::endl;
   
   return 0;
}
