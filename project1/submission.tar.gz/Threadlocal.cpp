#include "Workstore.hpp"

thread_local std::queue<uint64_t> local_queue; // Threads has their own queue to recycle nodes