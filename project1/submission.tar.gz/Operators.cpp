#include <cassert>
#include <chrono>
#include <cstring>
#include <iostream>
#include <fstream>

#include "Executeoptions.hpp"
#include "Operators.hpp"
#include "Threadpool.hpp"


using namespace std;


extern ThreadPool threadpool;

constexpr unsigned PROBE_COUNT_MAX = 20;

constexpr unsigned SMALL_RESULT_SIZE = 10000;


// Require a column and add it to results
bool Scan::require(SelectInfo info)
{
  // Check required relation is same with this scanning operator's relation

  if (info.binding != relationBinding)
    return false;

  assert(info.colId < relation.columns.size());

#ifdef MULTI_THREAD_MODE
  std::lock_guard<std::mutex> lock(mutex);
#endif
    
  resultColumns.push_back(relation.columns[info.colId]);  // Store starting address of required column
    
  select2ResultColId[info] = resultColumns.size() - 1;    // Store index of resultColumns. If there are duplicated columns, last pushed index will be stored

  return true;
}

// Run
void Scan::run()
{
  // Nothing to do
  resultSize = relation.size;
}

// Get materialized results
vector<uint64_t*> Scan::getResults()
{
  return resultColumns;
}

// Require a column and add it to results
bool FilterScan::require(SelectInfo info)
{
  // Check required relation is same with this filtering operator's relation

  if (info.binding != relationBinding)
    return false;

  assert(info.colId < relation.columns.size());

#ifdef MULTI_THREAD_MODE
  std::lock_guard<std::mutex> lock(mutex);
#endif

  // If requiring column id is not exist in result yet

  if (select2ResultColId.find(info) == select2ResultColId.end()) 
  {
    // Add to results

    inputData.push_back(relation.columns[info.colId]);
    
    tmpResults.emplace_back();
    
    unsigned colId = tmpResults.size() - 1;
    
    select2ResultColId[info] = colId;
  } 

  return true;
}

#ifdef SINGLE_THREAD_MODE
// Copy to result
void FilterScan::copy2Result(uint64_t id)
{
  for (unsigned cId = 0; cId < inputData.size(); cId++)
    tmpResults[cId].push_back(inputData[cId][id]);  // inputData is a vector that stores column's starting address

  ++resultSize;
}
#endif
#ifdef MULTI_THREAD_MODE
/// Copy tuple to result
inline void FilterScan::copy2Result(uint64_t id, std::vector<std::vector<uint64_t>>& tmpResult)
{
  for (unsigned cId = 0; cId < inputData.size(); cId++)
    tmpResult[cId].push_back(inputData[cId][id]);
}
#endif

// Apply filter
bool FilterScan::applyFilter(uint64_t i, FilterInfo& f)
{
  auto compareCol = relation.columns[f.filterColumn.colId];
  
  auto constant = f.constant;
  
  switch (f.comparison) 
  {
    case FilterInfo::Comparison::Equal:
    
      return compareCol[i] == constant;
    
    case FilterInfo::Comparison::Greater:
    
      return compareCol[i] > constant;
    
    case FilterInfo::Comparison::Less:
    
       return compareCol[i] < constant;
  };

  return false;
}

// Run
void FilterScan::run()
{
#ifdef SINGLE_THREAD_MODE
  for (uint64_t i = 0; i < relation.size; i++) 
  {
    bool pass = true;


    // Apply filters
    // If any filtering conditions are false, the pass value will be false

    for (auto& f : filters) 
    {
      pass &= applyFilter(i, f);

      if (!pass)
        break;
    }


    // If this record passed all filters, copy it to the result

    if (pass)
      copy2Result(i);
  }
#endif
#ifdef MULTI_THREAD_MODE

  using TmpResult = std::vector<std::vector<uint64_t>>;
  
  // Divide loop

  auto probe = [this](uint64_t start, uint64_t end, std::shared_ptr<TmpResult> shared_vec)
                {
                  TmpResult& tmpResult = *shared_vec;

                  for (uint64_t i = start; i < end; i++) 
                  {
                    bool pass = true;


                    // Apply filters
                    // If any filtering conditions are false, the pass value will be false

                    for (auto& f : filters) 
                    {
                      pass &= applyFilter(i, f);

                      if (!pass)
                        break;
                    }


                    // If this record passed all filters, copy it to the result

                    if (pass)
                      copy2Result(i, tmpResult);
                  }
                };


  // Each threads has tmpResults seperately

  std::vector<std::shared_ptr<TmpResult>> shared_result_list;


  // The futures of each probes

  std::vector<std::future<void>> probe_list;

  
  // Initially set probe count to the max
  // Then modify it according to the number of targets

  int probe_cnt = PROBE_COUNT_MAX;

  uint64_t unit = relation.size > PROBE_COUNT_MAX ? relation.size / PROBE_COUNT_MAX : relation.size;

  for (int i = 0; i < PROBE_COUNT_MAX; i++)
  {
    // Make tmpResult for each probe

    std::shared_ptr<TmpResult> shared_result = std::make_shared<TmpResult>();

    // Make columns

    for (int colId = 0; colId < tmpResults.size(); colId++)
    {
      (*shared_result).emplace_back();
    }

    shared_result_list.push_back(shared_result);


    // Start probing (filtering)

    uint64_t start = i * unit;

    uint64_t end = i == PROBE_COUNT_MAX - 1 ? relation.size : start + unit;

    std::future<void> probe_unit = threadpool.Request(probe, start, end, shared_result);

    probe_list.push_back(std::move(probe_unit));

    
    // If target size is smaller than PROBE_COUNT_MAX, set the real probe count

    if (end == relation.size)
    {
      probe_cnt = i + 1;

      break;
    }
  }


  // Wait the probes and calculate overall size

  uint64_t size = 0; // To reserve the total vector

  for (int i = 0; i < probe_cnt; i++)
  {
    threadpool.RequestWait(std::move(probe_list[i]));

    std::shared_ptr<TmpResult> shared_result = shared_result_list[i];

    size += (*shared_result)[0].size(); // Each columns has same size, so just use any column. (Here just use the first column)
  }


  // Before combining, make space for elements

  for (int colId = 0; colId < tmpResults.size(); colId++)
  {
    tmpResults[colId] = new uint64_t[size];
  }


  // Combine the temporal results of probes

  auto combine = [this](uint64_t start, std::shared_ptr<TmpResult> shared_result, int colId) 
                  { 
                    TmpResult& tmpProbeResult = *shared_result;

                    memcpy(tmpResults[colId] + start, tmpProbeResult[colId].data(), sizeof(uint64_t) * tmpProbeResult[colId].size());
                  };

  std::vector<std::future<void>> combine_list;

  uint64_t start = 0;

  for (int i = 0; i < probe_cnt; i++)
  {
    std::shared_ptr<TmpResult> shared_result = shared_result_list[i];

    uint64_t tmp_size = (*shared_result)[0].size(); // Each columns has same size, so just use any column. (Here just use the first column)

    // If this probe has no result, skip it

    if (tmp_size == 0) 
    {
      continue;
    }

    // If temporal result size is too small, just combine it now

    else if (tmp_size < SMALL_RESULT_SIZE)
    {
      for (int colId = 0; colId < tmpResults.size(); colId++)
      {
        combine(start, shared_result, colId);
      }

      start += tmp_size;
    }

    // Otherwise, give it to the thread pool

    else
    {
      for (int colId = 0; colId < tmpResults.size(); colId++)
      {
        combine_list.push_back(std::move(threadpool.Request(combine, start, shared_result, colId)));
      }

      start += tmp_size;
    }
  }


  // Wait until combining is finished

  for (int i = 0; i < combine_list.size(); i++)
  {
    threadpool.RequestWait(std::move(combine_list[i]));
  }


  resultSize = size;

#endif
}

// Get materialized results
vector<uint64_t*> Operator::getResults()
{
  vector<uint64_t*> resultVector;

  for (auto& c : tmpResults) 
  {
#ifdef SINGLE_THREAD_MODE
    resultVector.push_back(c.data()); // Push temporal columns's starting address
#endif
#ifdef MULTI_THREAD_MODE
    resultVector.push_back(c);
#endif
  }
  
  return resultVector;
}

// Require a column and add it to results
bool Join::require(SelectInfo info)
{
  // Projection pushdown
  // "info" is the required projection. Push it to the left or right

#ifdef SINGLE_THREAD_MODE
  if (requestedColumns.count(info) == 0) 
  {
    bool success = false;
    
    if (left->require(info))
    {
      requestedColumnsLeft.emplace_back(info);
        
      success = true;
    } 
    else if (right->require(info)) 
    {
      requestedColumnsRight.emplace_back(info);
        
      success = true;
    }


    if (!success)
    {
      return false;
    }


    tmpResults.emplace_back();
      
    requestedColumns.emplace(info);
  }

  return true;
#endif
#ifdef MULTI_THREAD_MODE
  if (requestedColumns.count(info))
    return true;

  if (left->require(info))
  {
    std::lock_guard<std::mutex> lock(mutex);

    if (requestedColumns.count(info) == 0)
    {
      requestedColumnsLeft.emplace_back(info);

      tmpResults.emplace_back();
        
      requestedColumns.emplace(info);
    }
    
    return true;
  } 
  else if (right->require(info)) 
  {
    std::lock_guard<std::mutex> lock(mutex);

    if (requestedColumns.count(info) == 0)
    {
      requestedColumnsRight.emplace_back(info);

      tmpResults.emplace_back();
        
      requestedColumns.emplace(info);      
    }
    
    return true;
  }

  return false;
#endif
}

#ifdef SINGLE_THREAD_MODE
// Copy to result
void Join::copy2Result(uint64_t leftId, uint64_t rightId)
{
  unsigned relColId = 0;

  for (unsigned cId = 0; cId < copyLeftData.size(); cId++)
    tmpResults[relColId++].push_back(copyLeftData[cId][leftId]);

  for (unsigned cId = 0; cId < copyRightData.size(); cId++)
    tmpResults[relColId++].push_back(copyRightData[cId][rightId]);
  
  ++resultSize;
}
#endif
#ifdef MULTI_THREAD_MODE
// Copy to result
inline void Join::copy2Result(uint64_t leftId, uint64_t rightId, std::vector<std::vector<uint64_t>>& tmpResult)
{
  unsigned relColId = 0;

  for (unsigned cId = 0; cId < copyLeftData.size(); cId++)
    tmpResult[relColId++].push_back(copyLeftData[cId][leftId]);

  for (unsigned cId = 0; cId < copyRightData.size(); cId++)
    tmpResult[relColId++].push_back(copyRightData[cId][rightId]);

}
#endif

// Run
void Join::run()
{
#ifdef SINGLE_THREAD_MODE
  // Pushdown projections

  left->require(pInfo.left);

  right->require(pInfo.right);


  // Execute the operators below

  left->run();
  
  right->run();
#endif
#ifdef MULTI_THREAD_MODE

  // Pushdown projections than execute operators

  auto left_require = threadpool.Request([this]() { left->require(pInfo.left); });

  auto right_require = threadpool.Request([this]() { right->require(pInfo.right); });

  threadpool.RequestWait(std::move(left_require));

  threadpool.RequestWait(std::move(right_require));


  // Start execution then wait

  auto left_run = threadpool.Request([this]() { left->run(); });

  auto right_run = threadpool.Request([this]() { right->run(); });

  threadpool.RequestWait(std::move(left_run));

  threadpool.RequestWait(std::move(right_run));
#endif


  // Use smaller input for build

  if (left->resultSize > right->resultSize) 
  {
    swap(left, right);
  
    swap(pInfo.left, pInfo.right);
  
    swap(requestedColumnsLeft, requestedColumnsRight);
  }



  // Get the vector that stores required columns's starting address

  auto leftInputData = left->getResults();

  auto rightInputData = right->getResults();


  // Resolve the input columns

  unsigned resColId = 0;

  // Copy the starting address of columns that is requested to the left operator

  for (auto& info : requestedColumnsLeft) 
  {
    copyLeftData.push_back(leftInputData[left->resolve(info)]);

    select2ResultColId[info] = resColId++;
  }

  // Copy the starting address of columns that is requested to the right operator

  for (auto& info : requestedColumnsRight) 
  {
    copyRightData.push_back(rightInputData[right->resolve(info)]);
  
    select2ResultColId[info] = resColId++;
  }


  // If left or right operator has no results, set the results size 0.
  // Then exit

  if (left->resultSize == 0 || right->resultSize == 0)
  {
    resultSize = 0;

    return;
  }


  // To compare columns that are requried for join,
  // It must be able to access the starting address of that columns
  // Get the index into the array containing the starting addresses.

  auto leftColId = left->resolve(pInfo.left);
  
  auto rightColId = right->resolve(pInfo.right);


  // Build phase

  auto leftKeyColumn = leftInputData[leftColId];

  hashTable.reserve(left->resultSize * 2);
  
  for (uint64_t i = 0, limit = i + left->resultSize; i != limit; i++) 
  {
    hashTable.emplace(leftKeyColumn[i], i);
  }


  // Probe phase

  auto rightKeyColumn = rightInputData[rightColId];

#ifdef SINGLE_THREAD_MODE
  for (uint64_t i = 0, limit = i + right->resultSize; i != limit; i++) 
  {
    auto rightKey = rightKeyColumn[i];
    
    auto range = hashTable.equal_range(rightKey);
    
    for (auto iter = range.first; iter != range.second; iter++) 
    {
      copy2Result(iter->second, i); // iter->second : index of left key value, i : index of right key value
    }
  }
#endif
#ifdef MULTI_THREAD_MODE

  using TmpResult = std::vector<std::vector<uint64_t>>;

  // Divide loop

  auto probe = [this, &rightKeyColumn](uint64_t start, uint64_t end, std::shared_ptr<TmpResult> shared_vec)
                {
                  TmpResult& tmpResult = *shared_vec;

                  for (int i = start; i < end; i++)
                  {
                    auto rightKey = rightKeyColumn[i];
                        
                    auto range = hashTable.equal_range(rightKey);
                        
                    for (auto iter = range.first; iter != range.second; iter++) 
                    {
                       copy2Result(iter->second, i, tmpResult); // iter->second : index of left key value, i : index of right key value
                    }
                  }
                };
                
  
  // Each threads has tmpResults seperately

  std::vector<std::shared_ptr<TmpResult>> shared_result_list;


  // The futures of each probes

  std::vector<std::future<void>> probe_list;


  // Initially set probe count to the max
  // Then modify it according to the number of targets

  int probe_cnt = PROBE_COUNT_MAX;

  uint64_t unit = right->resultSize > PROBE_COUNT_MAX ? right->resultSize / PROBE_COUNT_MAX : right->resultSize;

  for (int i = 0; i < PROBE_COUNT_MAX; i++)
  {
    // Make tmpResult for each probe

    std::shared_ptr<TmpResult> shared_result = std::make_shared<TmpResult>();

    // Make columns

    for (int colId = 0; colId < tmpResults.size(); colId++)
    {
      (*shared_result).emplace_back();
    }

    shared_result_list.push_back(shared_result);


    // Start probing (Comparing)

    uint64_t start = i * unit;

    uint64_t end = i == PROBE_COUNT_MAX - 1 ? right->resultSize : start + unit;

    std::future<void> probe_unit = threadpool.Request(probe, start, end, shared_result);

    probe_list.push_back(std::move(probe_unit));


    // If target size is smaller than PROBE_COUNT_MAX, set the real probe count
    
    if (end == right->resultSize)
    {
      probe_cnt = i + 1;

      break;
    }
  }


  // Wait the probes and calculate overall size

  uint64_t size = 0; // To reserve the total vector

  for (int i = 0; i < probe_cnt; i++)
  {
    threadpool.RequestWait(std::move(probe_list[i]));

    std::shared_ptr<TmpResult> shared_result = shared_result_list[i];

    size += (*shared_result)[0].size(); // Each columns has same size, so just use any column. (Here just use the first column)
  }


  // Before combining, make space for elements

  for (int colId = 0; colId < tmpResults.size(); colId++)
  {
    tmpResults[colId] = new uint64_t[size];
  }

  
  // Combine the temporal results of probes

  auto combine = [this](uint64_t start, std::shared_ptr<TmpResult> shared_result, int colId) 
                  { 
                    TmpResult& tmpProbeResult = *shared_result;

                    memcpy(tmpResults[colId] + start, tmpProbeResult[colId].data(), sizeof(uint64_t) * tmpProbeResult[colId].size());
                  };

  std::vector<std::future<void>> combine_list;

  uint64_t start = 0;

  for (int i = 0; i < probe_cnt; i++)
  {
    std::shared_ptr<TmpResult> shared_result = shared_result_list[i];

    uint64_t tmp_size = (*shared_result)[0].size(); // Each columns has same size, so just use any column. (Here just use the first column)

    // If this probe has no result, skip it

    if (tmp_size == 0) 
    {
      continue;
    }

    // If temporal result size is too small, just combine it now

    else if (tmp_size < SMALL_RESULT_SIZE)
    {
      for (int colId = 0; colId < tmpResults.size(); colId++)
      {
        combine(start, shared_result, colId);
      }

      start += tmp_size;
    }

    // Otherwise, give it to the thread pool

    else
    {
      for (int colId = 0; colId < tmpResults.size(); colId++)
      {
        combine_list.push_back(std::move(threadpool.Request(combine, start, shared_result, colId)));
      }

      start += tmp_size;
    }
  }


  // Wait until combining is finished

  for (int i = 0; i < combine_list.size(); i++)
  {
    threadpool.RequestWait(std::move(combine_list[i]));
  }


  resultSize = size;

#endif
}

#ifdef SINGLE_THREAD_MODE
// Copy to result
void SelfJoin::copy2Result(uint64_t id)
{
  for (unsigned cId = 0; cId < copyData.size(); cId++)
    tmpResults[cId].push_back(copyData[cId][id]);

  ++resultSize;
}
#endif
#ifdef MULTI_THREAD_MODE
// Copy to result
inline void SelfJoin::copy2Result(uint64_t id, std::vector<std::vector<uint64_t>>& tmpResult)
{
  for (unsigned cId = 0; cId < copyData.size(); cId++)
    tmpResult[cId].push_back(copyData[cId][id]);
}
#endif

// Require a column and add it to results
bool SelfJoin::require(SelectInfo info)
{

  if (requiredIUs.count(info))
  {
      return true;
  }


  if(input->require(info)) 
  {
#ifdef MULTI_THREAD_MODE
  std::lock_guard<std::mutex> lock(mutex);
#endif

    tmpResults.emplace_back();
    
    requiredIUs.emplace(info);

    return true;
  }
    
  return false;
}

// Run
void SelfJoin::run()
{
  // Projection pushdown

#ifdef SINGLE_THREAD_MODE
  input->require(pInfo.left);

  input->require(pInfo.right); 
#endif
#ifdef MULTI_THREAD_MODE
  auto left_require = threadpool.Request([this]() { input->require(pInfo.left); });

  auto right_require = threadpool.Request([this]() { input->require(pInfo.right); });

  threadpool.RequestWait(std::move(left_require));

  threadpool.RequestWait(std::move(right_require));
#endif
  

  // Run the operators below

  input->run();


  // Get the column's starting address

  inputData = input->getResults();

  for (auto& iu : requiredIUs) 
  {
    auto id = input->resolve(iu);

    copyData.emplace_back(inputData[id]); // col id

    select2ResultColId.emplace(iu, copyData.size() - 1);
  }


  // Access to the columns

  auto leftColId = input->resolve(pInfo.left);

  auto rightColId = input->resolve(pInfo.right);

  auto leftCol = inputData[leftColId];

  auto rightCol = inputData[rightColId];

  // Compare left key is same with right key
#ifdef SINGLE_THREAD_MODE
  for (uint64_t i = 0; i < input->resultSize; i++) 
  {
    if (leftCol[i] == rightCol[i])
      copy2Result(i);
  }
#endif
#ifdef MULTI_THREAD_MODE

  using TmpResult = std::vector<std::vector<uint64_t>>;

  // Divide loop

  auto probe = [this, &leftCol, &rightCol](uint64_t start, uint64_t end, std::shared_ptr<TmpResult> shared_vec)
                {
                  TmpResult& tmpResult = *shared_vec;

                  for (uint64_t i = start; i < end; i++) 
                  {
                    if (leftCol[i] == rightCol[i])
                      copy2Result(i, tmpResult);
                  }
                };

  
  // Each threads has tmpResults seperately

  std::vector<std::shared_ptr<TmpResult>> shared_result_list;


  // The futures of each probes

  std::vector<std::future<void>> probe_list;


  // Initially set probe count to the max
  // Then modify it according to the number of targets

  int probe_cnt = PROBE_COUNT_MAX;

  uint64_t unit = input->resultSize > PROBE_COUNT_MAX ? input->resultSize / PROBE_COUNT_MAX : input->resultSize;

  for (int i = 0; i < PROBE_COUNT_MAX; i++)
  {
    // Make tmpResult for each probe

    std::shared_ptr<TmpResult> shared_result = std::make_shared<TmpResult>();

    // Make columns

    for (int colId = 0; colId < tmpResults.size(); colId++)
    {
      (*shared_result).emplace_back();
    }

    shared_result_list.push_back(shared_result);


    // Start probing (Comparing)

    uint64_t start = i * unit;

    uint64_t end = i == PROBE_COUNT_MAX - 1 ? input->resultSize : start + unit;

    std::future<void> probe_unit = threadpool.Request(probe, start, end, shared_result);

    probe_list.push_back(std::move(probe_unit));


    // If target size is smaller than PROBE_COUNT_MAX, set the real probe count
    
    if (end == input->resultSize)
    {
      probe_cnt = i + 1;

      break;
    }
  }


  // Wait the probes and calculate overall size

  uint64_t size = 0; // To reserve the total vector

  for (int i = 0; i < probe_cnt; i++)
  {
    threadpool.RequestWait(std::move(probe_list[i]));

    std::shared_ptr<TmpResult> shared_result = shared_result_list[i];

    size += (*shared_result)[0].size(); // Each columns has same size, so just use any column. (Here just use the first column)
  }


  // Before combining, make space for elements

  for (int colId = 0; colId < tmpResults.size(); colId++)
  {
    tmpResults[colId] = new uint64_t[size];
  }
  
  
  // Combine the temporal results of probes

  auto combine = [this](uint64_t start, std::shared_ptr<TmpResult> shared_result, int colId) 
                  { 
                    TmpResult& tmpProbeResult = *shared_result;

                    memcpy(tmpResults[colId] + start, tmpProbeResult[colId].data(), sizeof(uint64_t) * tmpProbeResult[colId].size());
                  };

  std::vector<std::future<void>> combine_list;

  uint64_t start = 0;

  for (int i = 0; i < probe_cnt; i++)
  {
    std::shared_ptr<TmpResult> shared_result = shared_result_list[i];

    uint64_t tmp_size = (*shared_result)[0].size(); // Each columns has same size, so just use any column. (Here just use the first column)

    // If this probe has no result, skip it

    if (tmp_size == 0) 
    {
      continue;
    }

    // If temporal result size is too small, just combine it now

    else if (tmp_size < SMALL_RESULT_SIZE)
    {
      for (int colId = 0; colId < tmpResults.size(); colId++)
      {
        combine(start, shared_result, colId);
      }

      start += tmp_size;
    }

    // Otherwise, give it to the thread pool

    else
    {
      for (int colId = 0; colId < tmpResults.size(); colId++)
      {
        combine_list.push_back(std::move(threadpool.Request(combine, start, shared_result, colId)));
      }

      start += tmp_size;
    }
  }


  // Wait until combining is finished

  for (int i = 0; i < combine_list.size(); i++)
  {
    threadpool.RequestWait(std::move(combine_list[i]));
  }
  

  resultSize = size;

#endif
}

// Run
void Checksum::run()
{
  // Projection pushdown
  // About the list of columns that are needed to compute the final check sum,
  // Require to include these columns in the result of the operation

#ifdef SINGLE_THREAD_MODE
  for (auto& sInfo : colInfo) 
  {
    input->require(sInfo);
  }
#endif
#ifdef MULTI_THREAD_MODE
  std::vector<std::future<void>> require_list;
  
  for (auto& sInfo : colInfo) 
  {
    require_list.push_back(std::move(threadpool.Request([this, sInfo]() { input->require(sInfo); })));
  }

  for (int i = 0; i < require_list.size(); i++)
  {
    threadpool.RequestWait(std::move(require_list[i]));
  }
#endif


  // Start operation

  input->run();


  // Get the sum of each required columns

  auto results = input->getResults();

  for (auto& sInfo : colInfo) 
  {
    auto colId = input->resolve(sInfo);
  
    auto resultCol = results[colId];
  
    uint64_t sum = 0;
  
    resultSize = input->resultSize;
  
    for (auto iter = resultCol, limit = iter + input->resultSize; iter != limit; iter++)
      sum += *iter;
  
    checkSums.push_back(sum);
  }
}
