#ifndef WORKSTORE_HPP
#define WORKSTORE_HPP

#include <atomic>
#include <chrono>
#include <stdint.h>
#include <pthread.h>
#include <queue>
#include <iostream>


// In this project, thread pool is used
// The thread pool repeats saving and loading their works

// This data sturcture is used for it
// Both storing and loading do not use mutex

// The cost of storing is cheap, just push the work to the next of dummy
// But loading can be a linear search. So the cost of loading can be expensive

// cf) This data structure is not a queue, so order of nodes is not important


extern thread_local std::queue<uint64_t> local_queue; // Threads has their own queue to recycle nodes


template <typename WorkType>
struct WorkNode
{
  std::atomic<int> mark = 0; // Whether this node is working

  WorkType work;

  WorkNode<WorkType>* next = nullptr;
};

template <typename WorkType>
struct DummyWorkNode
{
  std::atomic<WorkNode<WorkType>*> next = nullptr;
};

template <typename WorkType>
class WorkStore
{
public:

  ~WorkStore()
  {
    WorkNode<WorkType>* now = dummy.next.load();

    WorkNode<WorkType>* target = nullptr;

    while (now)
    {
      target = now;

      now = now->next;

      delete target;
    }
  }

  // Loading
  bool operator>>(WorkType& work)
  {
    // At first, check the last updated node
    
    WorkNode<WorkType>* last = last_updated_node;

    // If the last updated node has no mark, try mark it
    // When marking is success, use it.
    // Otherwise, start linear search from dummy's next

    if (last && !last->mark && !std::atomic_fetch_or(&(last->mark), 1))
    {
      work = std::move(last->work);

      local_queue.push((uint64_t)last);

      return true;
    }

    
    // Start linear search from the next of dummy

    WorkNode<WorkType>* now = dummy.next.load();

    // Move until reach the end

    while (now)
    {
      // If this node was marked, it means that there are another thread working on this node. Then move to the next
      // Otherwise, get the work from the node

      if (!now->mark && !std::atomic_fetch_or(&(now->mark), 1)) // Atomically mark and check whether this node was already marked
      {
        // Get the work

        work = std::move(now->work);

        // Push the pointer to the local thread for recycling

        local_queue.push((uint64_t)now);

        return true;
      }

      now = now->next;
    }

    return false;
  }

  // Saving
  void operator<<(WorkType work)
  {
    WorkNode<WorkType>* new_work = nullptr;

    // If thread has a node for recycilng, use it
    // Otherwise, make new one

    if (local_queue.empty())
    {
      new_work = new WorkNode<WorkType>;

      new_work->work = std::move(work);

      last_updated_node = new_work;

      // Connect to the dummy

      WorkNode<WorkType>* prev = dummy.next.exchange(new_work, std::memory_order_seq_cst); 

      new_work->next = prev;
    }
    else
    {
      // Do not touch the order between nodes
      // Because if order is changed, cycle can be maded
      // It menas that infinite loop can be maded

      new_work = (WorkNode<WorkType>*)local_queue.front();

      local_queue.pop();

      new_work->work = std::move(work);

      last_updated_node = new_work;

      new_work->mark.store(0); // Setting is over, clear the mark
    }
  }

private:

  DummyWorkNode<WorkType> dummy;

  WorkNode<WorkType>* last_updated_node = nullptr;

};

#endif  // WORKSTORE_HPP
