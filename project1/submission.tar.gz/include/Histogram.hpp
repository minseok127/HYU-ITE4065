#ifndef HISTOGRAM_HPP
#define HISTOGRAM_HPP


#include <assert.h>
#include <stdint.h>


constexpr unsigned HISTOGRAM_BAR_COUNT = 100;


class Histogram
{
public:

  Histogram() {}

  ~Histogram() {}

  Histogram(const Histogram& h)
  {
    this->arr = h.arr;

    this->size = h.size;

    for (int i = 0; i < HISTOGRAM_BAR_COUNT; i++)
    {
      this->heights[i] = h.heights[i];
    }

    this->max = h.max;

    this->min = h.min;

    this->width = h.width;
  }

  Histogram(Histogram&& h)
  {
    this->arr = h.arr; h.arr = nullptr;

    this->size = h.size; h.size = 0;

    for (int i = 0; i < HISTOGRAM_BAR_COUNT; i++)
    {
      this->heights[i] = h.heights[i]; h.heights[i] = 0;
    }

    this->max = h.max; h.max = 0;

    this->min = h.min; h.min = 0;

    this->width = h.width; h.width = 0;
  }

  void Build(uint64_t* arr, uint64_t size)
  {
    assert(arr != nullptr && size != 0);

    this->size = size;

    this->arr = arr;
    
    uint64_t ceiled_max = 0;

    uint64_t quotient = 0;

  
    // Find max, min

    max = arr[0];

    min = arr[0];

    for (uint64_t i = 0; i < size; i++)
    {
      max = max > arr[i] ? max : arr[i];

      min = min < arr[i] ? min : arr[i];
    }


    // Before setting width, get the ceiled max

    if ((max - min + 1) % HISTOGRAM_BAR_COUNT)
    {
      quotient = (max - min + 1) / HISTOGRAM_BAR_COUNT;

      ceiled_max = (quotient + 1) * HISTOGRAM_BAR_COUNT + min;
    }
    else
    {
      ceiled_max = max;
    }


    // Set the width with ceiled max

    width = (ceiled_max - min + 1) / HISTOGRAM_BAR_COUNT;


    // Fill the bars of histogram

    for (uint64_t i = 0; i < size; i++)
    {
      uint64_t value = arr[i];

      uint64_t index = (value - min) / width;

      assert(index >= 0 || index < HISTOGRAM_BAR_COUNT);

      heights[index]++;
    }
  }

  double GetUpperSelectivity(uint64_t value)
  {
    if (value > max || value < min)
      return 0;
      
    uint64_t index = (value - min) / width;
    
    assert(index >= 0 || index < HISTOGRAM_BAR_COUNT);

    uint64_t bar_max = (index + 1) * width + min - 1;

    uint64_t bar_cnt = heights[index];

    double upper_cnt = 0;


    // Get the sum of heights that are higher than value's bar

    for (int i = index + 1; i < HISTOGRAM_BAR_COUNT; i++)
    {
      upper_cnt += heights[i];
    }

    // Get the sum of count that are higher than inside of same bar

    upper_cnt += (double)bar_cnt * (bar_max - value + 1) / width;


    // Return selectivity

    return (double)(upper_cnt) / size;
  }

  double GetLowerSelectivity(uint64_t value)
  {
    if (value > max || value < min)
      return 0;

    uint64_t index = (value - min) / width;

    assert(index >= 0 || index < HISTOGRAM_BAR_COUNT);

    uint64_t bar_min = index * width + min;

    uint64_t bar_cnt = heights[index];

    double lower_cnt = 0;


    // Get the sum of heights that are lower than value's bar

    for (int i = 0; i < index; i++)
    {
      lower_cnt += heights[i];
    }

    // Get the sum of count that are higher than inside of same bar

    lower_cnt += (double)bar_cnt * (value - bar_min + 1) / width;


    // Return selectivity

    return (double)(lower_cnt) / size;
  }

  double GetEquiSelectivity(uint64_t value)
  {
    if (value > max || value < min)
      return 0;

    uint64_t index = (value - min) / width;

    assert(index >= 0 || index < HISTOGRAM_BAR_COUNT);

    uint64_t bar_cnt = heights[index];

    double possibility_bar = (double)bar_cnt / size;      // The possibility of selecting this bar at the entire histogram

    double possibliity_inside_bar = bar_cnt ? 1 / (double)bar_cnt : 0;  // The possibility of selecting this value at this bar


    // Return selectivity

    return possibility_bar * possibliity_inside_bar;
  }

private:

  uint64_t* arr = nullptr;

  uint64_t size = 0;

  uint64_t max = 0;

  uint64_t min = 0;

  uint64_t heights[HISTOGRAM_BAR_COUNT] = {0};

  uint64_t width = 0;

};


#endif  // HISTOGRAM_HPP