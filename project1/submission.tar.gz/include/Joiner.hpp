#pragma once

#include <vector>
#include <cstdint>
#include <set>

#include "Parser.hpp"
#include "Operators.hpp"
#include "Relation.hpp"


class Joiner 
{
public:

  /// The relations that might be joined
  std::vector<Relation> relations;

  /// Add relation
  void addRelation(const char* fileName);

  /// Get relation
  Relation& getRelation(unsigned id);

  /// Joins a given set of relations
  std::string join(QueryInfo& i);

  /// Optimize joins
  void Optimize(QueryInfo& query);

  /// Set expected result size
  void SetExpectedSize(PredicateInfo& predicate, std::vector<FilterInfo>& filters);

  /// Get selectivity
  double GetSelectivity(SelectInfo& info, std::vector<FilterInfo>& filters);

  /// Get selectivity
  double GetSelectivity(FilterInfo& info);

  /// Get selectivity
  double GetSelectivity(PredicateInfo& info);

private:

  /// Add scan to query
  std::unique_ptr<Operator> addScan(std::set<unsigned>& usedRelations,SelectInfo& info,QueryInfo& query);
  
};