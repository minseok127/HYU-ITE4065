#pragma once

#include <cassert>
#include <deque>
#include <future>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <set>

#include "Executeoptions.hpp"
#include "Parser.hpp"
#include "Relation.hpp"


namespace std 
{
  /// Simple hash function to enable use with unordered_map
  template<> struct hash<SelectInfo> 
  {
    std::size_t operator()(SelectInfo const& s) const noexcept 
    {
      return s.binding ^ (s.colId << 5); 
    }
  };
};


class Operator 
{
  /// Operators materialize their entire result
  
public:

  /// Require a column and add it to results
  virtual bool require(SelectInfo info) = 0;

  /// Resolves a column
  unsigned resolve(SelectInfo info) { assert(select2ResultColId.find(info) != select2ResultColId.end()); return select2ResultColId[info]; }

  /// Run
  virtual void run() = 0;

  /// Get  materialized results
  virtual std::vector<uint64_t*> getResults();

  /// The result size
  uint64_t resultSize=0;

  /// The destructor
  virtual ~Operator() 
  {
#ifdef MULTI_THREAD_MODE
    for (uint64_t* col : tmpResults)
    {
      if (col)
        delete[] col;
    }
#endif
  }


protected:  

  /// The materialized results
  std::vector<uint64_t*> resultColumns;         

  /// The tmp results
#ifdef SINGLE_THREAD_MODE
  std::vector<std::vector<uint64_t>> tmpResults; 
#endif
#ifdef MULTI_THREAD_MODE
  std::vector<uint64_t*> tmpResults; 
#endif

  /// Mapping from select info to data
  std::unordered_map<SelectInfo, unsigned> select2ResultColId;

  /// Mutex
  std::mutex mutex;
  
};

class Scan : public Operator 
{
public:
  
  /// The constructor
  Scan(Relation& r, unsigned relationBinding) : relation(r), relationBinding(relationBinding) {};
  
  /// Require a column and add it to results
  bool require(SelectInfo info) override;
  
  /// Run
  void run() override;
  
  /// Get  materialized results
  virtual std::vector<uint64_t*> getResults() override;


protected:
  
  /// The relation
  Relation& relation;
  
  /// The name of the relation in the query
  unsigned relationBinding;

};

class FilterScan : public Scan 
{
public:

  /// The constructor
  FilterScan(Relation& r, std::vector<FilterInfo> filters) : Scan(r, filters[0].filterColumn.binding), filters(filters)  {};

  /// The constructor
  FilterScan(Relation& r, FilterInfo& filterInfo) : FilterScan(r, std::vector<FilterInfo>{filterInfo}) {};

  /// Require a column and add it to results
  bool require(SelectInfo info) override;

  /// Run
  void run() override;

  /// Get  materialized results
  virtual std::vector<uint64_t*> getResults() override { return Operator::getResults(); }

private:

  /// The filter info
  std::vector<FilterInfo> filters;
  
  /// The input data
  std::vector<uint64_t*> inputData;
  
  /// Apply filter
  bool applyFilter(uint64_t id, FilterInfo& f);
  
#ifdef SINGLE_THREAD_MODE
  /// Copy tuple to result
  void copy2Result(uint64_t id);
#endif
#ifdef MULTI_THREAD_MODE
  /// Copy tuple to result
  inline void copy2Result(uint64_t id, std::vector<std::vector<uint64_t>>& tmpResult);
#endif

};

class Join : public Operator 
{
public:

  /// The constructor
  Join(std::unique_ptr<Operator>&& left, std::unique_ptr<Operator>&& right, PredicateInfo& pInfo) : left(std::move(left)), right(std::move(right)), pInfo(pInfo) {};
  
  /// Require a column and add it to results
  bool require(SelectInfo info) override;
  
  /// Run
  void run() override;


private:

  /// The input operators
  std::unique_ptr<Operator> left, right;
  
  /// The join predicate info
  PredicateInfo& pInfo;
  
#ifdef SINGLE_THREAD_MODE
  /// Copy tuple to result
  void copy2Result(uint64_t leftId, uint64_t rightId);
#endif
#ifdef MULTI_THREAD_MODE
  /// Copy tuple to result
  inline void copy2Result(uint64_t leftId, uint64_t rightId, std::vector<std::vector<uint64_t>>& tmpResult);
#endif

  /// Create mapping for bindings
  void createMappingForBindings();

  using HT = std::unordered_multimap<uint64_t, uint64_t>;

  /// The hash table for the join
  HT hashTable;
  
  /// Columns that have to be materialized
  std::unordered_set<SelectInfo> requestedColumns;
  
  /// Left/right columns that have been requested
  std::vector<SelectInfo> requestedColumnsLeft,requestedColumnsRight;


  /// The entire input data of left and right
  std::vector<uint64_t*> leftInputData,rightInputData;
  
  /// The input data that has to be copied
  std::vector<uint64_t*> copyLeftData,copyRightData;

};

class SelfJoin : public Operator 
{
public:

  /// The constructor
  SelfJoin(std::unique_ptr<Operator>&& input, PredicateInfo& pInfo) : input(std::move(input)), pInfo(pInfo) {};

  /// Require a column and add it to results
  bool require(SelectInfo info) override;

  /// Run
  void run() override;

private:

  /// The input operators
  std::unique_ptr<Operator> input;
  
  /// The join predicate info
  PredicateInfo& pInfo;
  
#ifdef SINGLE_THREAD_MODE
  /// Copy tuple to result
  void copy2Result(uint64_t id);
#endif
#ifdef MULTI_THREAD_MODE
  /// Copy tuple to result
  inline void copy2Result(uint64_t id, std::vector<std::vector<uint64_t>>& tmpResult);
#endif
  
  /// The required IUs
  std::set<SelectInfo> requiredIUs;

  /// The entire input data
  std::vector<uint64_t*> inputData;
  
  /// The input data that has to be copied
  std::vector<uint64_t*> copyData;
};

class Checksum : public Operator 
{
public:

  std::vector<uint64_t> checkSums;

  /// The constructor
  Checksum(std::unique_ptr<Operator>&& input, std::vector<SelectInfo>& colInfo) : input(std::move(input)), colInfo(colInfo) {};

  /// Request a column and add it to results
  bool require(SelectInfo info) override { throw; /* check sum is always on the highest level and thus should never request anything */ }

  /// Run
  void run() override;

private:

  /// The input operator
  std::unique_ptr<Operator> input;

  /// The join predicate info
  std::vector<SelectInfo>& colInfo;

};