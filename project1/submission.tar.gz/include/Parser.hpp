#pragma once

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include "Relation.hpp"


struct SelectInfo 
{
   /// Relation id
   RelationId relId;

   /// Binding for the relation
   unsigned binding;
   
   /// Column id
   unsigned colId;
   

   /// The constructor
   SelectInfo(RelationId relId, unsigned b, unsigned colId) : relId(relId), binding(b), colId(colId) {};
   
   /// The constructor if relation id does not matter
   SelectInfo(unsigned b, unsigned colId) : SelectInfo(-1, b, colId) {};

   /// Copy constructor
   SelectInfo(const SelectInfo& o) { relId = o.relId; binding = o.binding; colId = o.colId; }

   /// Move constructor
   SelectInfo(SelectInfo&& o) { relId = o.relId; binding = o.binding; colId = o.colId; }

   /// Equality operator
   inline bool operator==(const SelectInfo& o) const 
   {
     return o.relId == relId && o.binding == binding && o.colId == colId;
   }

   /// Less Operator
   inline bool operator<(const SelectInfo& o) const 
   {
     return binding < o.binding || colId < o.colId;
   }

   /// = operator
   inline void operator=(const SelectInfo& o)
   {
      relId = o.relId; binding = o.binding; colId = o.colId;
   }   

   /// Dump text format
   std::string dumpText();

   /// Dump SQL
   std::string dumpSQL(bool addSUM = false);

   /// The delimiter used in our text format
   static const char delimiter = ' ';

   /// The delimiter used in SQL
   constexpr static const char delimiterSQL[] = ", ";
};

struct FilterInfo 
{
   enum Comparison : char { Less = '<', Greater = '>', Equal = '=' };

   /// Filter Column
   SelectInfo filterColumn;
   
   /// Constant
   uint64_t constant;
   
   /// Comparison type
   Comparison comparison;


   /// Dump SQL
   std::string dumpSQL();

   /// The constructor
   FilterInfo(SelectInfo filterColumn, uint64_t constant, Comparison comparison) : filterColumn(filterColumn), constant(constant), comparison(comparison) {};

   /// Copy constructor
   FilterInfo(const FilterInfo& f) : filterColumn(f.filterColumn), constant(f.constant), comparison(f.comparison) {};

   /// Move constructor
   FilterInfo(FilterInfo&& f) : filterColumn(std::move(f.filterColumn)), constant(std::move(f.constant)), comparison(std::move(f.comparison)) {};

   /// Equal operator
   void operator=(const FilterInfo& f) { filterColumn = f.filterColumn; constant = f.constant; comparison = f.comparison; }
   
   /// Dump text format
   std::string dumpText();

   /// The delimiter used in our text format
   static const char delimiter = '&';
   
   /// The delimiter used in SQL
   constexpr static const char delimiterSQL[] = " and ";
};

static const std::vector<FilterInfo::Comparison> comparisonTypes { FilterInfo::Comparison::Less, FilterInfo::Comparison::Greater, FilterInfo::Comparison::Equal};

struct PredicateInfo 
{
   /// Left
   SelectInfo left;
   
   /// Right
   SelectInfo right;

   /// Expected result size
   double expected_resultSize = 0;
   
   
   /// The constructor
   PredicateInfo(SelectInfo left, SelectInfo right) : left(left), right(right){};

   /// Copy constructor
   PredicateInfo(const PredicateInfo& p) : left(p.left), right(p.right) { expected_resultSize = p.expected_resultSize; }

   /// Move constructor
   PredicateInfo(PredicateInfo&& p) : left(std::move(p.left)), right(std::move(p.right)) { expected_resultSize = p.expected_resultSize; }
   
   /// Dump text format
   std::string dumpText();
   
   /// Dump SQL
   std::string dumpSQL();

   /// Comparing operator to sort
   bool operator<(const PredicateInfo& p) const { return this->expected_resultSize < p.expected_resultSize; }

   /// Equal operator
   void operator=(const PredicateInfo& p) { left = p.left; right = p.right; expected_resultSize = p.expected_resultSize; }

   /// The delimiter used in our text format
   static const char delimiter='&';

   /// The delimiter used in SQL
   constexpr static const char delimiterSQL[]=" and ";
};

class QueryInfo 
{
public:

   /// The relation ids
   std::vector<RelationId> relationIds;
   
   /// The predicates
   std::vector<PredicateInfo> predicates;
   
   /// The filters
   std::vector<FilterInfo> filters;
   
   /// The selections
   std::vector<SelectInfo> selections;
   
   /// Reset query info
   void clear();

   QueryInfo(const QueryInfo& other)
   {
      this->relationIds = other.relationIds;

      this->predicates = other.predicates;

      this->filters = other.filters;

      this->selections = other.selections;
   }

   QueryInfo(QueryInfo&& other)
   {
      this->relationIds = std::move(other.relationIds);

      this->predicates = std::move(other.predicates);

      this->filters = std::move(other.filters);

      this->selections = std::move(other.selections);
   }


private:

   /// Parse a single predicate
   void parsePredicate(std::string& rawPredicate);
   
   /// Resolve bindings of relation ids
   void resolveRelationIds();


public:
   
   /// Parse relation ids <r1> <r2> ...
   void parseRelationIds(std::string& rawRelations);
   
   /// Parse predicates r1.a=r2.b&r1.b=r3.c...
   void parsePredicates(std::string& rawPredicates);
   
   /// Parse selections r1.a r1.b r3.c...
   void parseSelections(std::string& rawSelections);
   
   /// Parse selections [RELATIONS]|[PREDICATES]|[SELECTS]
   void parseQuery(std::string& rawQuery);
   
   /// Dump text format
   std::string dumpText();
   
   /// Dump SQL
   std::string dumpSQL();
   
   /// The empty constructor
   QueryInfo() {}
   
   /// The constructor that parses a query
   QueryInfo(std::string rawQuery);
   
};