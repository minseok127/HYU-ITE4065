#ifndef THREADPOOL_HPP
#define THREADPOOL_HPP

#include <atomic>
#include <condition_variable>
#include <functional>
#include <future>
#include <iostream>
#include <mutex>
#include <thread>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include "Workstore.hpp"


// To reduce the cost of creation and deletion of threads
// Use thread pool

// Once thread is created, it will be not deleted until destructor is called.
// If there are no work, threads will sleep until new work is maded

// Each threads has stop flag
// When destructor is called, these stop flags will be changed to true


class ThreadPool
{
public:

    ThreadPool(int size) : size(size)
    {
        // Make worker threads 

        work_threads.reserve(size);

        stop_flags.reserve(size);

        for (int i = 0; i < size; i++)
        {          
            // Make stop flag to control thread

            bool* stop_flag = new bool;

            *stop_flag = false;

            stop_flags.push_back(stop_flag);


            // Make new thread

            work_threads.emplace_back([this, stop_flag]() { this->DoWork(stop_flag); }); // Make thread instance that is doing Dowork()

            work_threads[i].detach();
        }
    }

    ~ThreadPool()
    {
        // Set the stop flag, so worker threads can notice

        for (int i = 0; i < size; i++)
        {   
            *stop_flags[i] = true;
        }
        

        // Wake up all threads, so all threads can notice stop flag

        std::unique_lock<std::mutex> lock(sleep_mutex);

        cond.notify_all();
    }

    // Request work to the thread pool
    template <typename Function, typename... Args>
    std::future<typename std::invoke_result<Function, Args...>::type> Request(Function&& f, Args&&... args)
    {
        using return_t = typename std::invoke_result<Function, Args...>::type; // invoke_result says function's return type

        // Since these pointers are not used in here, make shared pointer to used at other working threads
        // If shared pointer is not used, objects will be removed from stack. Then the work threads will not be able to use these objects

        auto work = std::bind(std::forward<Function>(f), std::forward<Args>(args)...);

        std::shared_ptr<std::packaged_task<return_t()>> pckg_work_ptr = std::make_shared<std::packaged_task<return_t()>>(work);


        // Make future corresponding work promise

        auto work_future = pckg_work_ptr->get_future();


        // Make lambda function that copy shared pointers and execute the packaged work
        // Then push it to the work-store

        work_store << ([pckg_work_ptr]() { (*pckg_work_ptr)(); });


        // Wake up sleeping thread

        {
            std::unique_lock<std::mutex> lock(sleep_mutex, std::defer_lock);

            if (lock.try_lock())
                cond.notify_one();
        }


        // Return the futre corresponding new work

        return std::move(work_future);
    }

    // Manage the task with threadpool's policy
    template <typename ObjectType>
    std::future<ObjectType>&& RequestWait(std::future<ObjectType>&& f)
    {
        // To avoid deadlock, 
        // If all threads are blocked, branch new thread

        if (++blocked_count == size)
            branch();

        f.wait();

        blocked_count--;

        return std::move(f);
    }

    // Manage the task with threadpool's policy
    template <typename ObjectType>
    ObjectType RequestGet(std::future<ObjectType>&& f)
    {
        // To avoid deadlock, 
        // If all threads are blocked, branch new thread

        if (++blocked_count == size)
            branch();

        f.wait();

        blocked_count--;

        return f.get();
    }


private:

    // Worker thread's function
    void DoWork(bool* stop_flag)
    {
        while (true)
        {
            if (*stop_flag)
            {
                delete stop_flag;
                    
                return;
            }
            
            // Load the new work from work-store

            std::function<void()> work;

            if (work_store >> work)
            {
                // If store has work, do it
                
                work();
            }
            else
            {
                // If store has no work, go to sleep
            
                std::unique_lock<std::mutex> lock(sleep_mutex, std::defer_lock);

                if (lock.try_lock())
                {
                    if (*stop_flag)
                    {
                        delete stop_flag;

                        return;
                    }

                    cond.wait(lock);
                }
            }
        }
    }

    // Add new thread to thread pool
    void branch()
    {
        // Make stop flag to control thread

        bool* stop_flag = new bool;

        *stop_flag = false;


        branch_mutex.lock();


        // Push stop flag

        int i = size++;

        stop_flags.push_back(stop_flag);
        

        // Make new thread

        work_threads.emplace_back([this, stop_flag]() { this->DoWork(stop_flag); }); // Make thread instance that is doing Dowork()


        branch_mutex.unlock();


        work_threads[i].detach();
    }


    int size = 0;

    std::atomic<int> blocked_count = 0;

    std::vector<bool*> stop_flags;

    std::vector<std::thread> work_threads;

    WorkStore<std::function<void()>> work_store;


    // Mutex and conditional variable for waiting

    std::mutex sleep_mutex;

    std::condition_variable cond;


    // Mutexe for branching new thread

    std::mutex branch_mutex; 

};

#endif  // THREADPOOL_HPP
