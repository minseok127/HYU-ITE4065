#include <fcntl.h>
#include <iostream>
#include <fstream>
#include <sys/mman.h>
#include <sys/stat.h>

#include "Relation.hpp"


using namespace std;


// Stores a relation into a binary file
void Relation::storeRelation(const string& fileName)
{
  ofstream outFile;

  outFile.open(fileName, ios::out | ios::binary);
  

  // Header

  outFile.write((char*)&size, sizeof(size));
  
  auto numColumns = columns.size();
  
  outFile.write((char*)&numColumns, sizeof(size_t));
  

  // Data

  for (auto c : columns) 
  {
    outFile.write((char*)c, size * sizeof(uint64_t));
  }
  

  outFile.close();
}


// Stores a relation into a file (csv), e.g., for loading/testing it with a DBMS
void Relation::storeRelationCSV(const string& fileName)
{
  ofstream outFile;

  outFile.open(fileName+".tbl",ios::out);
  
  
  for (uint64_t i = 0; i < size; i++) 
  {
    for (auto& c : columns) 
    {
      outFile << c[i] << '|';
    }

    outFile << "\n";
  }
}


// Dump SQL: Create and load table (PostgreSQL)
void Relation::dumpSQL(const string& fileName, unsigned relationId)
{
  ofstream outFile;

  outFile.open(fileName + ".sql", ios::out);
  
  
  // Create table statement
  
  outFile << "CREATE TABLE r" << relationId << " (";
  
  for (unsigned cId = 0; cId < columns.size(); cId++) 
  {
    outFile << "c" << cId << " bigint" << (cId < columns.size() -1 ? "," : "");
  }
  
  outFile << ");\n";


  // Load from csv statement
  
  outFile << "copy r" << relationId << " from 'r" << relationId << ".tbl' delimiter '|';\n";
}


void Relation::loadRelation(const char* fileName)
{
  int fd = open(fileName, O_RDONLY);

  if (fd == -1) 
  {
    cerr << "cannot open " << fileName << endl;
    
    throw;
  }


  // Obtain file size
  
  struct stat sb;
  
  if (fstat(fd, &sb) == -1)
    cerr << "fstat\n";

  auto length = sb.st_size;


  // Map the file to the memory

  char* addr = static_cast<char*>(mmap(nullptr, length, PROT_READ, MAP_PRIVATE, fd, 0u));

  if (addr == MAP_FAILED) 
  {
    cerr << "cannot mmap " << fileName << " of length " << length << endl;
    
    throw;
  }

  if (length < 16) 
  {
    cerr << "relation file " << fileName << " does not contain a valid header" << endl;
    
    throw;
  }


  // Interpret header

  this->size = *reinterpret_cast<uint64_t*>(addr); // The number of tuples
  
  addr += sizeof(size);
  
  auto numColumns=*reinterpret_cast<size_t*>(addr); // The number of columns
  
  addr += sizeof(size_t);

  
  // Store starting address of columns

  for (unsigned i = 0; i < numColumns; i++) 
  {
    this->columns.push_back(reinterpret_cast<uint64_t*>(addr));
    
    addr += size*sizeof(uint64_t);
  }
}


// Constructor that loads relation from disk
Relation::Relation(const char* fileName) : ownsMemory(false)
{
  loadRelation(fileName);
}


// Destructor
Relation::~Relation()
{
  if (ownsMemory) 
  {
    for (auto c : columns)
      delete[] c;
  }
}


/// Build histograms
void Relation::BuildHistogram()
{
  // Make histograms for each columns
  // Then build it
  
  for (int colId = 0; colId < columns.size(); colId++)
  {
    histograms.emplace_back();
  
    histograms[colId].Build(columns[colId], size);
  }
}  