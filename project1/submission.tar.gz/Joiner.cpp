#include <algorithm>
#include <cassert>
#include <iostream>
#include <string>
#include <unordered_map>
#include <utility>
#include <set>
#include <sstream>
#include <vector>

#include "Joiner.hpp"
#include "Parser.hpp"
#include "Threadpool.hpp"


extern ThreadPool threadpool;


using namespace std;


// Loads a relation from disk
void Joiner::addRelation(const char* fileName)
{
  relations.emplace_back(fileName);
}


// Loads a relation from disk
Relation& Joiner::getRelation(unsigned relationId)
{
  if (relationId >= relations.size()) 
  {
    cerr << "Relation with id: " << relationId << " does not exist" << endl;

    throw;
  }

  return relations[relationId];
}


// Add scan to query
unique_ptr<Operator> Joiner::addScan(set<unsigned>& usedRelations, SelectInfo& info, QueryInfo& query)
{
  // Scan this SelectInfo is also in the query.filters

  usedRelations.emplace(info.binding);

  vector<FilterInfo> filters;
  
  for (auto& f : query.filters) 
  {
    // If this relation has filtering operations, save these filtering informations

    if (f.filterColumn.binding == info.binding) 
    {
      filters.emplace_back(f);
    }
  }

  // If this relation has filtering operations, return the operator as FilterScan
  // else, just return the operator as Scan

  return filters.size() ? make_unique<FilterScan>(getRelation(info.relId), filters) : make_unique<Scan>(getRelation(info.relId), info.binding);
}


enum QueryGraphProvides {  Left, Right, Both, None };


// Analyzes inputs of join
static QueryGraphProvides analyzeInputOfJoin(set<unsigned>& usedRelations, SelectInfo& leftInfo, SelectInfo& rightInfo)
{
  // Whether this relation is scaned

  bool usedLeft = usedRelations.count(leftInfo.binding);

  bool usedRight = usedRelations.count(rightInfo.binding);


  if (usedLeft ^ usedRight)
    return usedLeft ? QueryGraphProvides::Left : QueryGraphProvides::Right;

  if (usedLeft && usedRight)
    return QueryGraphProvides::Both;

  return QueryGraphProvides::None;
}


/// Optimize joins
void Joiner::Optimize(QueryInfo& query)
{
  // Set the expected result size of each joins

#ifdef MULTI_THREAD_MODE
  std::vector<std::future<void>> settings;
#endif

  for (int i = 0; i < query.predicates.size(); i++)
  {
#ifdef SINGLE_THREAD_MODE
    SetExpectedSize(query.predicates[i], query.filters);
#endif
#ifdef MULTI_THREAD_MODE
    settings.push_back(std::move(threadpool.Request([this, &query, i]() { SetExpectedSize(query.predicates[i], query.filters); })));
#endif
  }

#ifdef MULTI_THREAD_MODE
  for (int i = 0; i < query.predicates.size(); i++)
  {
    threadpool.RequestWait(std::move(settings[i]));
  }
#endif


  // Sort predicates
  // The predicate that has smallest expected result size will be come front of query

  std::sort(query.predicates.begin(), query.predicates.end());
}


/// Set expected result size
void Joiner::SetExpectedSize(PredicateInfo& predicate, std::vector<FilterInfo>& filters)
{
  // Get selectivity

  double left_selectivity = GetSelectivity(predicate.left, filters);

  double right_selectivity = GetSelectivity(predicate.right, filters);

  double join_selectivity = GetSelectivity(predicate);

  double total_selectivity = left_selectivity * right_selectivity * join_selectivity;


  // Get maximum result size

  uint64_t left_size = getRelation(predicate.left.relId).size;

  uint64_t right_size = getRelation(predicate.right.relId).size;

  uint64_t max_result_size = left_size * right_size;

  
  // Set expected result size

  predicate.expected_resultSize = max_result_size * total_selectivity;
}


/// Get selectivity
double Joiner::GetSelectivity(SelectInfo& info, std::vector<FilterInfo>& filters)
{
  double selectivity = 1;

  for (auto& f : filters) 
  {
    // If this relation has filtering operations, save these filtering informations

    if (f.filterColumn.binding == info.binding) 
    {
      selectivity *= GetSelectivity(f);
    }
  }

  return selectivity;
}


/// Get selectivity
double Joiner::GetSelectivity(FilterInfo& info)
{
  Relation& r = getRelation(info.filterColumn.relId);

  int colId = info.filterColumn.colId;


  switch (info.comparison)
  {
  case FilterInfo::Comparison::Less:
    
    return r.histograms[colId].GetLowerSelectivity(info.constant);

  case FilterInfo::Comparison::Greater:

    return r.histograms[colId].GetUpperSelectivity(info.constant);

  case FilterInfo::Comparison::Equal:

    return r.histograms[colId].GetEquiSelectivity(info.constant);
  }

  return 1;
}


/// Get selectivity
double Joiner::GetSelectivity(PredicateInfo& predicate)
{
  double selectivity = 0;

  uint64_t left_size = getRelation(predicate.left.relId).size;

  uint64_t right_size = getRelation(predicate.right.relId).size;

  Relation& small_relation = left_size > right_size ? getRelation(predicate.right.relId) : getRelation(predicate.left.relId);

  Relation& big_relation = left_size > right_size ? getRelation(predicate.left.relId) : getRelation(predicate.right.relId);

  int small_relation_colId = left_size > right_size ? predicate.right.colId : predicate.left.colId;

  int big_relation_colId = left_size > right_size ? predicate.left.colId : predicate.right.colId;


  // Iterate small relation

  for (uint64_t i = 0; i < small_relation.size; i++)
  {
    uint64_t value = small_relation.columns[small_relation_colId][i];

    double small_relation_selectivity = small_relation.histograms[small_relation_colId].GetEquiSelectivity(value);

    double big_relation_selectivity = big_relation.histograms[big_relation_colId].GetEquiSelectivity(value);

    selectivity += small_relation_selectivity * big_relation_selectivity;
  }
  

  return selectivity;
}


// Executes a join query
// We use left-deep join tree
string Joiner::join(QueryInfo& query)
{
  //cerr << query.dumpText() << endl;

  set<unsigned> usedRelations;


#ifdef QUERY_OPTIMIZE_MODE
  // Before making join tree, optimize predicates

  Optimize(query);
#endif


  // Make Operators about first join
  // With addScan(), find filtering operations to the target relation

  auto& firstJoin = query.predicates[0];

  auto left = addScan(usedRelations, firstJoin.left, query);
  
  auto right = addScan(usedRelations, firstJoin.right, query);


  // Make first join operator as a root of join tree

  unique_ptr<Operator> root = make_unique<Join>(move(left), move(right), firstJoin);


  // Add another operators into join tree

  for (unsigned i = 1; i < query.predicates.size(); i++) 
  {
    // Make Operator about join

    auto& pInfo = query.predicates[i];

    auto& leftInfo = pInfo.left; auto& rightInfo = pInfo.right;

    unique_ptr<Operator> left, right;


    // Push new join operator to the join tree
    
    switch(analyzeInputOfJoin(usedRelations, leftInfo, rightInfo)) 
    {
      case QueryGraphProvides::Left:

        // If left realtion is already in join tree,
        // Change left of this join operator as root, new join operator will be new root

        left = move(root);

        right = addScan(usedRelations, rightInfo, query);
        
        root = make_unique<Join>(move(left), move(right), pInfo);
        
        break;

      case QueryGraphProvides::Right:

        // If right realtion is already in join tree,
        // Change right of this join operator as root, new join operator will be new root
        
        left = addScan(usedRelations, leftInfo, query);
        
        right = move(root);
        
        root = make_unique<Join>(move(left), move(right), pInfo);

        break;
      
      case QueryGraphProvides::Both:
        
        // All relations of this join are already used somewhere else in the query.
        // Thus, we have either a cycle in our join graph or more than one join predicate per join.
        
        root = make_unique<SelfJoin>(move(root), pInfo);
        
        break;
      
      case QueryGraphProvides::None:
        
        // Process this predicate later when we can connect it to the other joins
        // We never have cross products
        
        query.predicates.push_back(pInfo);
        
        break;
    };
  }
  

  // Join and get the sum

  Checksum checkSum(move(root), query.selections);
  
  checkSum.run();


  // Print results

  stringstream out;

  auto& results = checkSum.checkSums;
  
  for (unsigned i = 0; i < results.size(); i++) 
  {
    out << (checkSum.resultSize == 0 ? "NULL" : to_string(results[i]));

    if (i < results.size() - 1)
      out << " ";
  }

  out << "\n";
  
  return out.str();
}